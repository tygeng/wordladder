#ifndef SETBUILDER
#define SETBUILDER
#include"vector.h"
#include"hashset.h"
#include"node.h"

int related(char* this, char* that);
void build(char* fileName, Hashset* index, Vector* dic);
#endif
